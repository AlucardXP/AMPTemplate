Run cod4x18_dedrun for normal operation of server
Run cod4x18_dedrun_dbg if you have problems. Only report issues when using the cod4x18_dedrun_dbg file.
If you operatingsystem does not provide the required version of libstdc++.so.6 file copy the file from "runtime" to the same place as cod4x18_dedrun file
File main/xbase_00.iwd contains new plugins
